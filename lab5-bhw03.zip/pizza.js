function getSize() {
    rangevalue = document.getElementById("p-range").value;
    console.log(rangevalue)
    ChangePizzaSize()
    return rangevalue
}

function getMeet() {
    ids = ["pepperoni", "sausage", "groundbeef", "anchovy", "chicken"];
    meat = []
    for (i = 0; i < ids.length; i++) {
        if (document.getElementById(ids[i]).checked)
            meat.push(document.getElementById(ids[i]).value)
    }
    console.log(meat);
    return meat
}

function getVeg() {
    ids = ["tomatoes", "Onions", "Olives", "Mushrooms", "Pineapple", "Spinach", "Jalapeno"];
    pizzaveggies = []
    for (i = 0; i < ids.length; i++) {
        if (document.getElementById(ids[i]).checked)
            pizzaveggies.push(document.getElementById(ids[i]).value)
    }
    console.log(pizzaveggies)
    return pizzaveggies
}

function getCheese() {
    ids = ["reg", "no", "extra"];
    for (i = 0; i < ids.length; i++) {
        if (document.getElementById(ids[i]).checked) {
            if (document.getElementById(ids[i]).value == "regular cheese") {
                console.log(1);
                return 1
            }
            if (document.getElementById(ids[i]).value == "extra cheese") {
                console.log(3);
                return 3
            }
            else {
                console.log(2);
                return 2
            }
        }
    }
}

function ChangePizzaSize() {
    rangevalue = document.getElementById("p-range").value;
    if (rangevalue == 1) {
        document.getElementById("pizza-img").width = "100";
        document.getElementById("p-size").innerHTML = "Small";
        document.getElementById("price").innerHTML = 6;
    }
    else if (rangevalue == 2) {
        document.getElementById("pizza-img").width = "150";
        document.getElementById("p-size").innerHTML = "Medium:";
        document.getElementById("price").innerHTML = 10;
    }
    else if (rangevalue == 3) {
        document.getElementById("pizza-img").width = "200";
        document.getElementById("p-size").innerHTML = "Large:";
        document.getElementById("price").innerHTML = 14;
    }
    else if (rangevalue == 4) {
        document.getElementById("pizza-img").width = "250";
        document.getElementById("p-size").innerHTML = "X-Large:";
        document.getElementById("price").innerHTML = 16;
    }
    calculateTotal()

}

function calculateTotal() {
    size = document.getElementById("p-range").value;
    meat = getMeet();
    pizzaveggis = getVeg();
    cheese = getCheese();
    cheeseprice = 0;
    if (cheese == 3) { cheeseprice = 3 }
    price = 0
    if (size == 1)
        price = 6
    else if (size == 2)
        price = 10
    else if (size == 3)
        price = 14
    else
        price = 16

    total_price = price + (2 * meat.length) + pizzaveggis.length + cheeseprice;
    console.log(total_price)
    return total_price
}

function fillSummary() {
    fname = document.getElementById("fname").value;
    lname = document.getElementById("lname").value;
    email = document.getElementById("email").value;
    phone = document.getElementById("phone").value;
    city = document.getElementById("city").value;
    add = document.getElementById("addressss").value;
    dileverto = fname + " " + lname + ", " + email + ", " + phone + ", " + city + ", " + add;
    document.getElementById("dlvrTo").innerHTML = dileverto;

    size = document.getElementById("p-range").value;
    meat = getMeet();
    veggis = getVeg();
    cheese = getCheese();
    cheeseprice = 0;
    cheess = "extra"
    if (cheese == 3) { cheess = "Extra Cheese" }
    psize = ""
    if (size == 1)
        psize = "Small"
    else if (size == 2)
        psize = "Meduium"
    else if (size == 3)
        psize = "Large"
    else
        psize = "X-Large"

    ordersum = ""
    if (cheess == "Extra Cheese")
        ordersum = '<li>' + cheess + '</li>'

    order = []
    order.push(...meat)
    order.push(...veggis)

    for (i = 0; i < order.length; i++) {
        ordersum += '<li>' + order[i] + '</li>'
    }
    document.getElementById("orderList").innerHTML = '<li>' + psize + " size" + '</li>' + ordersum;

    total_price = calculateTotal();
    document.getElementById("total").innerHTML = 'Total: ' + total_price + ' $';
}

function goToPage(idto, idfrom) {
    if (idto == "OrderSummary") {
        if (checkInfo()) {
            document.getElementById(idfrom).style.display = "none";
            next = document.getElementById(idto);
            next.style.display = "block";
        }
        else{
            alert("Some info are missed")
            return 
        }

    }
    else {
        document.getElementById(idfrom).style.display = "none";
        next = document.getElementById(idto);
        body = document.getElementById("main-body")
        next.style.display = "block";
    }
    if (idfrom == "forms" || idto=="address") {
        body.style.backgroundColor = "#e93a57";
    }
    else if (idfrom == "address" && idto == "forms") {
        body.style.backgroundColor = "#01dddd";

    }
    else {
        body.style.backgroundColor = "#3fc38e";
        fillSummary();
    }


}

function checkInfo() {
    fname = document.getElementById("fname").value;
    lname = document.getElementById("lname").value;
    email = document.getElementById("email").value;
    phone = document.getElementById("phone").value;
    city   = document.getElementById("city").value;
    add   = document.getElementById("addressss").value;
console.log(    fname)
console.log(    lname)
console.log(    email)
console.log(    phone)
console.log(    city )
console.log(    add  )

    if (fname.trim() && fname.trim() && lname.trim() && email.trim() && phone.trim() && city && add.trim())
        return true
    return false;


}